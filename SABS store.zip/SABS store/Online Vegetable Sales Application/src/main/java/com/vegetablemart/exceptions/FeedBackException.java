package com.vegetablemart.exceptions;

public class FeedBackException extends RuntimeException {

	public FeedBackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
	public FeedBackException() {
	
		// TODO Auto-generated constructor stub
	}
	
	

}
