package com.vegetablemart.enums;

public enum TransactionStatus {
    FAILED, SUCCESS, PENDING
}
