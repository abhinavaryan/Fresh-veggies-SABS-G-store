package com.vegetablemart.enums;

public enum TransactionMode {
                CASH_ON_DELIVERY,
                ONLINE
}
