package com.vegetablemart.exceptions;

public class UserException extends RuntimeException{

	public UserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	public UserException() {
		
		// TODO Auto-generated constructor stub
	}
	
	

}
