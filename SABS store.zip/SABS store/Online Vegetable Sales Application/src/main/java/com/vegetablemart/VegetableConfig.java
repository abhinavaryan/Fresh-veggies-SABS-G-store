package com.vegetablemart;

public class VegetableConfig {
}
