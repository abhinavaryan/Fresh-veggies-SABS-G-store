package com.vegetablemart.enums;

public enum OrderStatus {
    DELIVERED, ON_THE_WAY, CANCELLED, PENDING, PROCESSING, SHIPPED
}
