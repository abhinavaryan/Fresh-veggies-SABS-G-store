package com.vegetablemart.service;

public class UserException {

}
